from django.db import models

# Create your models here.

class User (models.Model):
	F_name=models.CharField (max_length=100)
	L_name=models.CharField (max_length=100)
	pswd=models.CharField(max_length=100)
	age=models.IntegerField()
	email=models.EmailField()
	address=models.TextField()

	def __str__(self):
		return self.F_name+" - "+self.L_name