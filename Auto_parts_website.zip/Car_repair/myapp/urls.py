from django.urls import path
from myapp import views

urlpatterns = [
    path('', views.index, name='index'),
    path('contact', views.contact, name='contact'),
    path('signup', views.signup,name='signup'),
    path('login',views.login,name='login'),
    path('forgotpswd',views.forgotpswd,name='forgotpswd'),
    path('verify_otp',views.verify_otp,name='verify_otp'),
    path('service', views.service,name='service'),
    path('about', views.about,name='about'),
    path('logout',views.logout,name="logout"),

]
