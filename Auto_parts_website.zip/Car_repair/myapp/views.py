from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import User
from django.conf import settings
from django.core.mail import send_mail
import random

def index(request):
    return render(request,'index.html')
def contact(request):
	return render(request,'contact.html')
def service(request):
	return render(request,'service.html')
def about(request):
	return render(request,'about.html')

def signup(request):
	if request.method=="POST":
		try:
			user=User.objects.get(email=request.POST ['email']) 
			msg1="Email Already Exist !!!"
			return render (request, 'signup.html',{'msg1' :msg1}) 
		except:
			User.objects.create(
				F_name=request.POST['F_name'],
				L_name=request.POST['L_name'], 
				pswd=request.POST['pswd'], 
				age=request.POST['age'],
				email=request.POST['email'],  
				address=request.POST['address']
			)
			msg= "Registration Done ..."
			return render (request, 'signup.html',{'msg' :msg})
	else:
		msg1= "Registration Not Done..."
		return render(request, 'signup.html')
def login(request):
	if request.method=="POST":
		user=User.objects.get(email=request.POST['email'],pswd=request.POST['pswd'])
		request.session['email']=user.email 
		request.session['F_name']=user.F_name 
		return render(request,'index.html')
	else:
		return render(request,'login.html')

def logout(request):
	del request.session['email']
	del request.session['F_name']

	return redirect('login')

def forgotpswd(request):
	if request.method=="POST":
		try:
			user=User.objects.get(email=request.POST['email'])
			subject='OTP for Forgot Password'
			otp=random.randint(1000,9999)
			message = f'Hi {user.F_name}, You OTP for forgot Password is : '+str(otp)
			email_from = settings.EMAIL_HOST_USER
			recipient_list = [user.email, ]			
			send_mail( subject, message, email_from, recipient_list )
			return render(request,'verify_otp.html', {'email':user.email,'otp':otp})			
		except:
			a="You are not a Registered User!!!!"
			return render(request, 'forgotpswd.html')

	else:
		return render(request, 'forgotpswd.html')

def verify_otp(request):
	if request.method=="POST":
		email=request.POST['email']
		otp=request.POST['otp']
		uotp=request.POST['uotp']

		if uotp==str(otp):
			return render(request,'new_pswd.html',{'email':email})
		else:
			msg1="OTP Doesn't Match !!!!"
			return render(request,'verify_otp.html',{'msg1':msg1})

	else:
		return render(request,'verify_otp.html')

def new_pswd(request):
	if request.method=="POST":

		email=request.POST['email']
		npswd=request.POST['new_pswd']
		cnpswd=request.POST['cnew_pswd']




		